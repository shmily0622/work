from django.shortcuts import render, redirect, get_object_or_404
from .forms import DayCreateForm
from .models import Day
from django.views import generic
from django.urls import reverse_lazy


class IndexView(generic.ListView):
    model = Day
    paginate_by = 3
# Create your views here.


class AddView(generic.CreateView):
    model = Day
    form_class = DayCreateForm
    success_url = reverse_lazy('diary:index')


class UpdateView(generic.UpdateView):
    model = Day
    form_class = DayCreateForm
    success_url = reverse_lazy('diary:index')


class DeleteView(generic.DeleteView):
    model = Day
    success_url = reverse_lazy('diary:index')


class DetailView(generic.DetailView):
    model = Day


# class ImageView(generic.FormView):
 #   model = Day
  #  form_class = DayCreateForm
   # success_url = reverse_lazy('diary:index')

    #model = Comment
    #form_class = CommentCreateForm
    #success_url = reverse_lazy('diary:index')
