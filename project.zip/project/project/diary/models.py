from django.db import models
from django.utils import timezone
# Create your models here.


class Day(models.Model):
    title = models.CharField('タイトル', max_length=200)
    text = models.TextField('本文')
    date = models.DateTimeField('日付', default=timezone.now)
    weather = models.CharField('天気', max_length=10)
    # 画像アップロード
    image = models.ImageField(upload_to='images', blank=True, null=True)
    # 画像アップロード

    def __str__(self):
        return self.title
