from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from . import views


from django.conf.urls import url
app_name = 'diary'

urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),  # /diary の場合
    path('add/', views.AddView.as_view(), name='add'),
    path('update/<int:pk>/', views.UpdateView.as_view(), name='update'),
    path('delete/<int:pk>', views.DeleteView.as_view(), name='delete'),
    path('detail/<int:pk>', views.DetailView.as_view(), name='detail'),
]
# 画像アップロード
if settings.DEBUG:
    urlpatterns += static(settings.IMAGE_URL,
                          document_root=settings.IMAGE_ROOT)
    # 画像アップロード
